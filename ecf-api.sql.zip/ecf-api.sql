-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le :  ven. 15 fév. 2019 à 09:32
-- Version du serveur :  5.7.23
-- Version de PHP :  7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ecf-api`
--

--
-- Déchargement des données de la table `migration_versions`
--

INSERT INTO `migration_versions` (`version`, `executed_at`) VALUES
('20190214111649', '2019-02-14 11:24:22');

--
-- Déchargement des données de la table `resource`
--

INSERT INTO `resource` (`id`, `soft`, `alcohol`, `food`) VALUES
(1, 'Coca', NULL, 'chips'),
(2, NULL, 'uby 4', NULL),
(3, NULL, NULL, 'pizza');

--
-- Déchargement des données de la table `resource_student`
--

INSERT INTO `resource_student` (`resource_id`, `student_id`) VALUES
(1, 1),
(2, 2),
(3, 3);

--
-- Déchargement des données de la table `student`
--

INSERT INTO `student` (`id`, `firstname`, `lastname`, `response`) VALUES
(1, 'Justine', 'Moreau', 1),
(2, 'Sullyvan', 'Delaby', 1),
(3, 'alexandre', 'Briffaut', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
